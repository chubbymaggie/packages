#!/usr/bin/env python
# -*- coding: utf-8 -*-
from   setuptools import setup
import os
import site


package_description = '''
LIEF is a library to instrument executable formats
'''.strip()

setup(
    name                 = 'lief',
    version              = '0.7.0',
    license              = "Apache 2.0",
    description          = package_description,
    url                  = 'http://lief.quarkslab.com',
    author               = 'Romain Thomas',
    author_email         = 'rthomas@quarkslab.com',
    packages             = [''],
    package_data         = {'': ['lief.pyd']},
    keywords             = 'elf pe macho',
    classifiers          = [
        'License :: OSI Approved :: Apache Software License',
        'Development Status :: 4 - Beta',
        'Environment :: Console',
        'Intended Audience :: Developers',
	'Intended Audience :: Science/Research',
        'Operating System :: MacOS :: MacOS X',
        'Operating System :: POSIX :: Linux',
        'Operating System :: Windows :: Windows',
        'Programming Language :: C++',
        'Programming Language :: Python :: 3.5',
        'Topic :: Software Development :: Libraries',
        'Topic :: Security',
        'Topic :: Scientific/Engineering :: Information Analysis',
	'Topic :: Software Development :: Build Tools',
    ]
)
